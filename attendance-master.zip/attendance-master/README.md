Attendance-python
==============

Small program for basic interface and logging of NFC tags on the Raspberry Pi


Pre Requisites
==============

You will need to install SPI-Py from lthiery from the following address:

https://github.com/lthiery/SPI-Py
You will also need GPIO-Py from page 
https://pypi.python.org/packages/source/R/RPi.GPIO/


More Info
==============

For more information visit: http://www.instructables.com/id/Attendance-system-using-Raspberry-Pi-and-NFC-Tag-r/


Usage
==============

Just run the following command:

sudo python attendance.py 


Liability
==============
This program is distributed for educational purposes only and is no way suitable for any particular application, especially commercial. There is no implied suitability so use at your own risk!


Licence
==============
This program is distributed under the Beer-ware licence (revision 42)

Jakub Dvorak wrote this file. As long as you retain this notice you can do whatever you want with this stuff. If we meet some day, and you think this stuff is worth it, you can buy me a beer in return.

